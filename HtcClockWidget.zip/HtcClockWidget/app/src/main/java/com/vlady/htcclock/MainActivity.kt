package com.vlady.htcclock

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView

/** Impostazioni del widget: le modifiche si vedono subito sul widget in home. */
class MainActivity : Activity() {

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private val fontNames = listOf("Sottile corsivo (HTC)", "Sottile", "Leggero", "Normale")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(20), dp(20), dp(20))
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        addText(root, "Orologio HTC", 22f)
        addText(
            root,
            "Aggiungi il widget dalla home (tieni premuto > Widget > Orologio HTC). " +
                "Le modifiche qui sotto si vedono subito sul widget.",
            14f
        )

        addText(root, "Orologio", 18f)
        addSeek(root, "Dimensione ora", 36, 90, "time", 44, " sp")
        addSeek(root, "Dimensione AM/PM", 8, 20, "ampm", 11, " sp")
        addFont(root, "Font dell'ora", "font_time", 0)

        addText(root, "Data e meteo", 18f)
        addSeek(root, "Dimensione data", 16, 40, "date", 20, " sp")
        addSeek(root, "Dimensione riga città/giorno/temperatura", 8, 16, "info", 10, " sp")
        addSeek(root, "Dimensione icona meteo", 16, 48, "icon", 20, " dp")
        addFont(root, "Font della data", "font_date", 2)

        addText(root, "Distanze", 18f)
        addSeek(root, "Distanza tra orologio e data", 0, 120, "gap", 10, " dp")
        addSeek(root, "Distanza tra le righe a destra", 0, 12, "linegap", 0, " dp")

        val reset = Button(this)
        reset.text = "Ripristina predefiniti"
        reset.setOnClickListener {
            ClockPrefs.sp(this).edit().clear().apply()
            ClockWidget.render(this)
            recreate()
        }
        root.addView(reset)
    }

    private fun addText(root: LinearLayout, s: String, size: Float) {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setPadding(0, dp(14), 0, dp(4))
        root.addView(t)
    }

    private fun addSeek(root: LinearLayout, label: String, min: Int, max: Int, key: String, def: Int, unit: String) {
        val cur = ClockPrefs.sp(this).getInt(key, def)
        val lbl = TextView(this)
        lbl.text = "$label: $cur$unit"
        lbl.setPadding(0, dp(8), 0, 0)
        root.addView(lbl)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                lbl.text = "$label: $v$unit"
                if (fromUser) {
                    ClockPrefs.sp(this@MainActivity).edit().putInt(key, v).apply()
                    ClockWidget.render(this@MainActivity)
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(sb)
    }

    private fun addFont(root: LinearLayout, label: String, key: String, def: Int) {
        val lbl = TextView(this)
        lbl.text = label
        lbl.setPadding(0, dp(8), 0, 0)
        root.addView(lbl)
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, fontNames)
        spinner.setSelection(ClockPrefs.sp(this).getInt(key, def).coerceIn(0, 3))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                if (ClockPrefs.sp(this@MainActivity).getInt(key, def) != pos) {
                    ClockPrefs.sp(this@MainActivity).edit().putInt(key, pos).apply()
                    ClockWidget.render(this@MainActivity)
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        root.addView(spinner)
    }
}
