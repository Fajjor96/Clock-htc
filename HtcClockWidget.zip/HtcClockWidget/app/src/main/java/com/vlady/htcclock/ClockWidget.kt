package com.vlady.htcclock

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.widget.RemoteViews
import androidx.work.*
import java.util.concurrent.TimeUnit

// MODIFICA QUI la tua città
const val CITY = "ROMA"
const val LAT = 41.9028
const val LON = 12.4964

class ClockWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        render(context)
        schedule(context)
    }

    override fun onEnabled(context: Context) {
        schedule(context)
        WorkManager.getInstance(context)
            .enqueue(OneTimeWorkRequestBuilder<WeatherWorker>().build())
    }

    private fun schedule(context: Context) {
        val req = PeriodicWorkRequestBuilder<WeatherWorker>(30, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork("weather", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    companion object {
        fun render(context: Context) {
            val prefs = context.getSharedPreferences("w", Context.MODE_PRIVATE)
            val views = RemoteViews(context.packageName, R.layout.widget)
            views.setTextViewText(R.id.w_city, CITY)
            views.setTextViewText(R.id.w_temp, "${prefs.getInt("temp", 0)}°".takeIf { prefs.contains("temp") } ?: "--°")
            views.setTextViewText(R.id.w_icon, prefs.getString("icon", "☀"))
            val mgr = AppWidgetManager.getInstance(context)
            mgr.updateAppWidget(ComponentName(context, ClockWidget::class.java), views)
        }
    }
}
