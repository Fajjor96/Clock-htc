package com.vlady.htcclock

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.widget.RemoteViews
import androidx.work.*
import java.util.concurrent.TimeUnit

// MODIFICA QUI la tua città
const val CITY = "ROMA"
const val LAT = 41.9028
const val LON = 12.4964

class ClockWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        render(context)
        schedule(context)
    }

    override fun onEnabled(context: Context) {
        schedule(context)
        WorkManager.getInstance(context)
            .enqueue(OneTimeWorkRequestBuilder<WeatherWorker>().build())
    }

    private fun schedule(context: Context) {
        val req = PeriodicWorkRequestBuilder<WeatherWorker>(30, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork("weather", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    companion object {
        fun render(context: Context) {
            val prefs = context.getSharedPreferences("w", Context.MODE_PRIVATE)
            val views = RemoteViews(context.packageName, R.layout.widget)
            views.setTextViewText(R.id.w_city, CITY)
            views.setTextViewText(R.id.w_temp, "${prefs.getInt("temp", 0)}°".takeIf { prefs.contains("temp") } ?: "--°")
            val name = "ic_w_%02d".format(prefs.getInt("code", 1))
            val res = context.resources.getIdentifier(name, "drawable", context.packageName)
            if (res != 0) views.setImageViewResource(R.id.w_icon, res)
            // Tocco su ora (e spazi vuoti): apre l'app Orologio (sveglie, timer, ecc.)
            val clockIntent = Intent(AlarmClock.ACTION_SHOW_ALARMS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val pi = PendingIntent.getActivity(
                context, 0, clockIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.root, pi)
            views.setOnClickPendingIntent(R.id.clock_area, pi)
            // Tocco su data e meteo: apre l'app Calendario predefinita
            val calIntent = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val calPi = PendingIntent.getActivity(
                context, 1, calIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.date_area, calPi)
            val mgr = AppWidgetManager.getInstance(context)
            mgr.updateAppWidget(ComponentName(context, ClockWidget::class.java), views)
        }
    }
}
