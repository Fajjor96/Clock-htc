package com.vlady.htcclock

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.net.URL
import kotlin.math.roundToInt

class WeatherWorker(private val ctx: Context, params: WorkerParameters) : Worker(ctx, params) {

    override fun doWork(): Result {
        return try {
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$LAT&longitude=$LON&current=temperature_2m,weather_code"
            val cur = JSONObject(URL(url).readText()).getJSONObject("current")
            val temp = cur.getDouble("temperature_2m").roundToInt()
            val icon = when (cur.getInt("weather_code")) {
                0, 1 -> "☀"
                2, 3, 45, 48 -> "☁"
                in 51..67, in 80..82 -> "☂"
                in 71..77, 85, 86 -> "❄"
                in 95..99 -> "⚡"
                else -> "☁"
            }
            ctx.getSharedPreferences("w", Context.MODE_PRIVATE).edit()
                .putInt("temp", temp).putString("icon", icon).apply()
            ClockWidget.render(ctx)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
